from django.db import models

class Item(models.Model):
    nome = models.CharField(max_length=100)
    codigo_referencia = models.CharField(max_length=50, unique=True)
    localizacao = models.CharField(max_length=100)
    quantidade = models.IntegerField(default=0)
    estoque_minimo = models.IntegerField(default=1)

    def em_alerta(self):
        return self.quantidade < self.estoque_minimo

    def __str__(self):
        return f"{self.nome} ({self.codigo_referencia})"

class Movimentacao(models.Model):
    TIPO_CHOICES = [
        ('entrada', 'Entrada'),
        ('saida', 'Saída'),
    ]

    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES)
    quantidade = models.PositiveIntegerField()
    data = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.tipo == 'entrada':
            self.item.quantidade += self.quantidade
        elif self.tipo == 'saida':
            self.item.quantidade -= self.quantidade
        self.item.save()
        super().save(*args, **kwargs)