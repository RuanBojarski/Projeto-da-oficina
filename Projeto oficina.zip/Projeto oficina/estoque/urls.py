from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('novo/', views.novo_item, name='novo_item'),
    path('movimentar/<int:item_id>/', views.movimentar, name='movimentar'),
]