from django.shortcuts import render, redirect, get_object_or_404
from .models import Item, Movimentacao
from django.utils import timezone

def dashboard(request):
    itens = Item.objects.all()
    return render(request, 'estoque/dashboard.html', {'itens': itens})

def novo_item(request):
    if request.method == 'POST':
        nome = request.POST['nome']
        codigo = request.POST['codigo']
        local = request.POST['local']
        quantidade = int(request.POST['quantidade'])
        minimo = int(request.POST['minimo'])

        Item.objects.create(
            nome=nome,
            codigo_referencia=codigo,
            localizacao=local,
            quantidade=quantidade,
            estoque_minimo=minimo
        )
        return redirect('dashboard')
    return render(request, 'estoque/novo_item.html')

def movimentar(request, item_id):
    item = get_object_or_404(Item, id=item_id)

    if request.method == 'POST':
        tipo = request.POST['tipo']
        quantidade = int(request.POST['quantidade'])

        Movimentacao.objects.create(
            item=item,
            tipo=tipo,
            quantidade=quantidade,
            data=timezone.now()
        )
        return redirect('dashboard')

    return render(request, 'estoque/movimentar.html', {'item': item})